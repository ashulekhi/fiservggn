import { Component, OnInit } from '@angular/core';
import { EmailValidator } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  name="Some Name"
  email=""
  password=""
  constructor() { }

  ngOnInit() {
  }

  login(){
    console.log("user credentials" , this.email , this.password)
  }

}
