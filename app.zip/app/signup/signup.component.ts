import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

let signupapi = "https://ashuapi.herokuapp.com/api/register"
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user = {
    name:'',
    email:'',
    password:''
  }
  constructor(private http:HttpClient) { 
  }
  ngOnInit() {
  }
  signup(){
    this.http.post(signupapi,this.user).subscribe((response)=>{
      console.log("response from signup api" , response)
    },(error)=>{
      console.log("error from signup api" , error) 
    })
  }

}
