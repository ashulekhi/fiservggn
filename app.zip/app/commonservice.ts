import {Injectable} from "@angular/core"

@Injectable()
export class CommonService{
  count = 0
}