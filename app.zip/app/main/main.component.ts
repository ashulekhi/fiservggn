import {Component} from "@angular/core"
import { CommonService } from '../commonservice';
import {HttpClient} from "@angular/common/http"

let getproductsapi = "https://ashuapi.herokuapp.com/api/allproducts"


@Component({
    selector:'app-main',
    templateUrl:'./main.component.html',
    styleUrls:['./main.component.css']
})
export class MainComponent{
    products=[]
    constructor(private cs : CommonService ,private http:HttpClient){
        console.log("this" , this);
        setTimeout(()=>{
            console.log("inside tieout" , this);
        },3000)
     this.http.get(getproductsapi).subscribe((response)=>{
         console.log("response from all products api" ,response)
       this.products = response["data"]
    
     },
    function(error){

    })
    }
   demo(){
     alert()
 }
 count
 getUsers(){
     this.count = this.cs.count
 }
}